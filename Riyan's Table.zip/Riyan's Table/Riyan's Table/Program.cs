namespace RiyanZafarTable // Updated namespace to reflect the new form name
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new RiyanZafarForm()); // Updated to reference RiyanZafarForm
        }
    }
}
