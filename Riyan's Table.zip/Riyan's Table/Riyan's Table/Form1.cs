using System;
using System.Data;
using System.Windows.Forms;

public partial class RiyanZafarForm : Form // Updated class name to reflect your name
{
    DataTable dt = new DataTable();

    public RiyanZafarForm() // Updated constructor name
    {
        InitializeComponent(); // This initializes all UI components
        CreateNewRow(); // Initialize columns when the form loads
    }

    public void CreateNewRow()
    {
        if (dt.Columns.Count == 0) // Create columns only once
        {
            dt.Columns.Add(new DataColumn("Course Code", typeof(string))); // Updated column name
            dt.Columns.Add(new DataColumn("Course Title", typeof(string))); // Updated column name
            dt.Columns.Add(new DataColumn("Obtained Marks", typeof(int))); // Updated column name
            dt.Columns.Add(new DataColumn("Grade", typeof(string))); // Updated column name
            dt.Columns.Add(new DataColumn("Status", typeof(string))); // Updated column name
        }
    }

    public void AddRowToDataTable()
    {
        // Add a new row with user inputs
        dt.Rows.Add(
            txt_courseCode.Text, // Assume there's a TextBox for course code
            txt_courseTitle.Text, // Assume there's a TextBox for course title
            Convert.ToInt32(txt_obtainedMarks.Text), // Assume there's a TextBox for obtained marks
            txt_grade.Text, // Assume there's a TextBox for grade
            txt_status.Text // Assume there's a TextBox for status
        );
        dataGridView1.DataSource = dt; // Update DataGridView with the new data
    }

    private void btn_add_Click(object sender, EventArgs e) // Changed button name for clarity
    {
        AddRowToDataTable(); // Call the method to add a new row when the button is clicked
    }
}
